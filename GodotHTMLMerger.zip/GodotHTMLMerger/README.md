===============================
Godot HTML Merger
===============================

Version: 1.0
Author: Zalan Tarján

Description:
-------------
Godot HTML Merger is a simple tool that allows you to merge Godot-exported HTML, JS, PCK, and WASM files
into a single offline HTML file. It includes an embedded loader so the game can run without external files.

How to use:
-------------
1. Run GodotHTMLMerger.exe
2. Select your HTML, JS, PCK, and WASM files using the buttons.
3. Click "Merge Files" to generate a single merged HTML file.
4. Open the generated HTML file in your browser to play your game offline.

Requirements:
-------------
- Windows 10 or later
- No installation needed

Credits:
-------------
- Made by Zalan Tarján
- Uses Python and CustomTkinter

Support:
-------------
For questions or issues, contact: zalantarjan77@gmail.com

Enjoy your offline Godot games!
